import React from 'react'

export default function LiebeDeutschSite() {
  return (
    <div className=\"min-h-screen flex items-center justify-center\">
      <h1 className=\"text-4xl font-bold\">Liebe Deutsch Website</h1>
      <p className=\"mt-4\">Learn German & English online. Business English and IELTS prep.</p>
    </div>
  )
}
