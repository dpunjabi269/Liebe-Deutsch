import React from 'react'

export default function LiebeDeutschSite() {
  return (
    <div className="min-h-screen flex items-center justify-center flex-col text-center p-8">
      <h1 className="text-4xl font-bold">Liebe Deutsch</h1>
      <p className="mt-4 text-lg max-w-xl">
        Learn German & English online. Courses for A1, A2, B1, B2. 
        Business English coaching and IELTS preparation. First demo session is free!
      </p>
      <p className="mt-6 font-semibold">Contact: +91 8080899952</p>
    </div>
  )
}
